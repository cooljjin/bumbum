"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[3365],{14814:(e,t,n)=>{n.d(t,{r:()=>i});let i=parseInt(n(85339).sPf.replace(/\D+/g,""))},15353:(e,t,n)=>{n.d(t,{D:()=>i});let i=n(14814).r>=125?"uv1":"uv2"},35814:(e,t,n)=>{n.d(t,{N:()=>u});var i=n(88945),r=n(12115),o=n(85339),a=n(96026),s=n(63592),l=n(57254),c=n(44733),d=n(94854),f=n(49736);let u=r.forwardRef(function(e,t){var n,u;let{points:p,color:h=0xffffff,vertexColors:m,linewidth:v,lineWidth:y,segments:g,dashed:x,...w}=e,S=(0,a.C)(e=>e.size),b=r.useMemo(()=>g?new s.b:new l.X,[g]),[E]=r.useState(()=>new c.G),_=(null==m||null==(n=m[0])?void 0:n.length)===4?4:3,A=r.useMemo(()=>{let e=g?new d.n:new f.v,t=p.map(e=>{let t=Array.isArray(e);return e instanceof o.Pq0||e instanceof o.IUQ?[e.x,e.y,e.z]:e instanceof o.I9Y?[e.x,e.y,0]:t&&3===e.length?[e[0],e[1],e[2]]:t&&2===e.length?[e[0],e[1],0]:e});if(e.setPositions(t.flat()),m){h=0xffffff;let t=m.map(e=>e instanceof o.Q1f?e.toArray():e);e.setColors(t.flat(),_)}return e},[p,g,m,_]);return r.useLayoutEffect(()=>{b.computeLineDistances()},[p,b]),r.useLayoutEffect(()=>{x?E.defines.USE_DASH="":delete E.defines.USE_DASH,E.needsUpdate=!0},[x,E]),r.useEffect(()=>()=>{A.dispose(),E.dispose()},[A]),r.createElement("primitive",(0,i.A)({object:b,ref:t},w),r.createElement("primitive",{object:A,attach:"geometry"}),r.createElement("primitive",(0,i.A)({object:E,attach:"material",color:h,vertexColors:!!m,resolution:[S.width,S.height],linewidth:null!=(u=null!=v?v:y)?u:1,dashed:x,transparent:4===_},w)))})},43646:(e,t,n)=>{let i,r;n.d(t,{E:()=>x});var o=n(88945),a=n(12115),s=n(12669),l=n(85339),c=n(96026);let d=new l.Pq0,f=new l.Pq0,u=new l.Pq0,p=new l.I9Y;function h(e,t,n){let i=d.setFromMatrixPosition(e.matrixWorld);i.project(t);let r=n.width/2,o=n.height/2;return[i.x*r+r,-(i.y*o)+o]}let m=e=>1e-10>Math.abs(e)?0:e;function v(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"",i="matrix3d(";for(let n=0;16!==n;n++)i+=m(t[n]*e.elements[n])+(15!==n?",":")");return n+i}let y=(i=[1,-1,1,1,1,-1,1,1,1,-1,1,1,1,-1,1,1],e=>v(e,i)),g=(r=e=>[1/e,1/e,1/e,1,-1/e,-1/e,-1/e,-1,1/e,1/e,1/e,1,1,1,1,1],(e,t)=>v(e,r(t),"translate(-50%,-50%)")),x=a.forwardRef((e,t)=>{let{children:n,eps:i=.001,style:r,className:v,prepend:x,center:w,fullscreen:S,portal:b,distanceFactor:E,sprite:_=!1,transform:A=!1,occlude:M,onOcclude:L,castShadow:P,receiveShadow:U,material:z,geometry:O,zIndexRange:C=[0x1000037,0],calculatePosition:D=h,as:R="div",wrapperClass:B,pointerEvents:T="auto",...H}=e,{gl:W,camera:I,scene:j,size:N,raycaster:q,events:F,viewport:G}=(0,c.C)(),[k]=a.useState(()=>document.createElement(R)),V=a.useRef(null),Q=a.useRef(null),X=a.useRef(0),Y=a.useRef([0,0]),J=a.useRef(null),Z=a.useRef(null),$=(null==b?void 0:b.current)||F.connected||W.domElement.parentNode,K=a.useRef(null),ee=a.useRef(!1),et=a.useMemo(()=>M&&"blending"!==M||Array.isArray(M)&&M.length&&function(e){return e&&"object"==typeof e&&"current"in e}(M[0]),[M]);a.useLayoutEffect(()=>{let e=W.domElement;M&&"blending"===M?(e.style.zIndex="".concat(Math.floor(C[0]/2)),e.style.position="absolute",e.style.pointerEvents="none"):(e.style.zIndex=null,e.style.position=null,e.style.pointerEvents=null)},[M]),a.useLayoutEffect(()=>{if(Q.current){let e=V.current=s.createRoot(k);if(j.updateMatrixWorld(),A)k.style.cssText="position:absolute;top:0;left:0;pointer-events:none;overflow:hidden;";else{let e=D(Q.current,I,N);k.style.cssText="position:absolute;top:0;left:0;transform:translate3d(".concat(e[0],"px,").concat(e[1],"px,0);transform-origin:0 0;")}return $&&(x?$.prepend(k):$.appendChild(k)),()=>{$&&$.removeChild(k),e.unmount()}}},[$,A]),a.useLayoutEffect(()=>{B&&(k.className=B)},[B]);let en=a.useMemo(()=>A?{position:"absolute",top:0,left:0,width:N.width,height:N.height,transformStyle:"preserve-3d",pointerEvents:"none"}:{position:"absolute",transform:w?"translate3d(-50%,-50%,0)":"none",...S&&{top:-N.height/2,left:-N.width/2,width:N.width,height:N.height},...r},[r,w,S,N,A]),ei=a.useMemo(()=>({position:"absolute",pointerEvents:T}),[T]);a.useLayoutEffect(()=>{var e,i;ee.current=!1,A?null==(e=V.current)||e.render(a.createElement("div",{ref:J,style:en},a.createElement("div",{ref:Z,style:ei},a.createElement("div",{ref:t,className:v,style:r,children:n})))):null==(i=V.current)||i.render(a.createElement("div",{ref:t,style:en,className:v,children:n}))});let er=a.useRef(!0);(0,c.D)(e=>{if(Q.current){I.updateMatrixWorld(),Q.current.updateWorldMatrix(!0,!1);let e=A?Y.current:D(Q.current,I,N);if(A||Math.abs(X.current-I.zoom)>i||Math.abs(Y.current[0]-e[0])>i||Math.abs(Y.current[1]-e[1])>i){let t=function(e,t){let n=d.setFromMatrixPosition(e.matrixWorld),i=f.setFromMatrixPosition(t.matrixWorld),r=n.sub(i),o=t.getWorldDirection(u);return r.angleTo(o)>Math.PI/2}(Q.current,I),n=!1;et&&(Array.isArray(M)?n=M.map(e=>e.current):"blending"!==M&&(n=[j]));let i=er.current;n?er.current=function(e,t,n,i){let r=d.setFromMatrixPosition(e.matrixWorld),o=r.clone();o.project(t),p.set(o.x,o.y),n.setFromCamera(p,t);let a=n.intersectObjects(i,!0);if(a.length){let e=a[0].distance;return r.distanceTo(n.ray.origin)<e}return!0}(Q.current,I,q,n)&&!t:er.current=!t,i!==er.current&&(L?L(!er.current):k.style.display=er.current?"block":"none");let r=Math.floor(C[0]/2),o=M?et?[C[0],r]:[r-1,0]:C;if(k.style.zIndex="".concat(function(e,t,n){if(t instanceof l.ubm||t instanceof l.qUd){let i=d.setFromMatrixPosition(e.matrixWorld),r=f.setFromMatrixPosition(t.matrixWorld),o=i.distanceTo(r),a=(n[1]-n[0])/(t.far-t.near),s=n[1]-a*t.far;return Math.round(a*o+s)}}(Q.current,I,o)),A){let[e,t]=[N.width/2,N.height/2],n=I.projectionMatrix.elements[5]*t,{isOrthographicCamera:i,top:r,left:o,bottom:a,right:s}=I,l=y(I.matrixWorldInverse),c=i?"scale(".concat(n,")translate(").concat(m(-(s+o)/2),"px,").concat(m((r+a)/2),"px)"):"translateZ(".concat(n,"px)"),d=Q.current.matrixWorld;_&&((d=I.matrixWorldInverse.clone().transpose().copyPosition(d).scale(Q.current.scale)).elements[3]=d.elements[7]=d.elements[11]=0,d.elements[15]=1),k.style.width=N.width+"px",k.style.height=N.height+"px",k.style.perspective=i?"":"".concat(n,"px"),J.current&&Z.current&&(J.current.style.transform="".concat(c).concat(l,"translate(").concat(e,"px,").concat(t,"px)"),Z.current.style.transform=g(d,1/((E||10)/400)))}else{let t=void 0===E?1:function(e,t){if(t instanceof l.qUd)return t.zoom;if(!(t instanceof l.ubm))return 1;{let n=d.setFromMatrixPosition(e.matrixWorld),i=f.setFromMatrixPosition(t.matrixWorld);return 1/(2*Math.tan(t.fov*Math.PI/180/2)*n.distanceTo(i))}}(Q.current,I)*E;k.style.transform="translate3d(".concat(e[0],"px,").concat(e[1],"px,0) scale(").concat(t,")")}Y.current=e,X.current=I.zoom}}if(!et&&K.current&&!ee.current)if(A){if(J.current){let e=J.current.children[0];if(null!=e&&e.clientWidth&&null!=e&&e.clientHeight){let{isOrthographicCamera:t}=I;if(t||O)H.scale&&(Array.isArray(H.scale)?H.scale instanceof l.Pq0?K.current.scale.copy(H.scale.clone().divideScalar(1)):K.current.scale.set(1/H.scale[0],1/H.scale[1],1/H.scale[2]):K.current.scale.setScalar(1/H.scale));else{let t=(E||10)/400,n=e.clientWidth*t,i=e.clientHeight*t;K.current.scale.set(n,i,1)}ee.current=!0}}}else{let t=k.children[0];if(null!=t&&t.clientWidth&&null!=t&&t.clientHeight){let e=1/G.factor,n=t.clientWidth*e,i=t.clientHeight*e;K.current.scale.set(n,i,1),ee.current=!0}K.current.lookAt(e.camera.position)}});let eo=a.useMemo(()=>({vertexShader:A?void 0:'\n          /*\n            This shader is from the THREE\'s SpriteMaterial.\n            We need to turn the backing plane into a Sprite\n            (make it always face the camera) if "transfrom"\n            is false.\n          */\n          #include <common>\n\n          void main() {\n            vec2 center = vec2(0., 1.);\n            float rotation = 0.0;\n\n            // This is somewhat arbitrary, but it seems to work well\n            // Need to figure out how to derive this dynamically if it even matters\n            float size = 0.03;\n\n            vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );\n            vec2 scale;\n            scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );\n            scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );\n\n            bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n            if ( isPerspective ) scale *= - mvPosition.z;\n\n            vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale * size;\n            vec2 rotatedPosition;\n            rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;\n            rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;\n            mvPosition.xy += rotatedPosition;\n\n            gl_Position = projectionMatrix * mvPosition;\n          }\n      ',fragmentShader:"\n        void main() {\n          gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);\n        }\n      "}),[A]);return a.createElement("group",(0,o.A)({},H,{ref:Q}),M&&!et&&a.createElement("mesh",{castShadow:P,receiveShadow:U,ref:K},O||a.createElement("planeGeometry",null),z||a.createElement("shaderMaterial",{side:l.$EB,vertexShader:eo.vertexShader,fragmentShader:eo.fragmentShader})))})},44733:(e,t,n)=>{n.d(t,{G:()=>a});var i=n(85339),r=n(87548),o=n(14814);class a extends i.BKk{constructor(e){super({type:"LineMaterial",uniforms:i.LlO.clone(i.LlO.merge([r.UniformsLib.common,r.UniformsLib.fog,{worldUnits:{value:1},linewidth:{value:1},resolution:{value:new i.I9Y(1,1)},dashOffset:{value:0},dashScale:{value:1},dashSize:{value:1},gapSize:{value:1}}])),vertexShader:`
				#include <common>
				#include <fog_pars_vertex>
				#include <logdepthbuf_pars_vertex>
				#include <clipping_planes_pars_vertex>

				uniform float linewidth;
				uniform vec2 resolution;

				attribute vec3 instanceStart;
				attribute vec3 instanceEnd;

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
						attribute vec4 instanceColorStart;
						attribute vec4 instanceColorEnd;
					#else
						varying vec3 vLineColor;
						attribute vec3 instanceColorStart;
						attribute vec3 instanceColorEnd;
					#endif
				#endif

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#ifdef USE_DASH

					uniform float dashScale;
					attribute float instanceDistanceStart;
					attribute float instanceDistanceEnd;
					varying float vLineDistance;

				#endif

				void trimSegment( const in vec4 start, inout vec4 end ) {

					// trim end segment so it terminates between the camera plane and the near plane

					// conservative estimate of the near plane
					float a = projectionMatrix[ 2 ][ 2 ]; // 3nd entry in 3th column
					float b = projectionMatrix[ 3 ][ 2 ]; // 3nd entry in 4th column
					float nearEstimate = - 0.5 * b / a;

					float alpha = ( nearEstimate - start.z ) / ( end.z - start.z );

					end.xyz = mix( start.xyz, end.xyz, alpha );

				}

				void main() {

					#ifdef USE_COLOR

						vLineColor = ( position.y < 0.5 ) ? instanceColorStart : instanceColorEnd;

					#endif

					#ifdef USE_DASH

						vLineDistance = ( position.y < 0.5 ) ? dashScale * instanceDistanceStart : dashScale * instanceDistanceEnd;
						vUv = uv;

					#endif

					float aspect = resolution.x / resolution.y;

					// camera space
					vec4 start = modelViewMatrix * vec4( instanceStart, 1.0 );
					vec4 end = modelViewMatrix * vec4( instanceEnd, 1.0 );

					#ifdef WORLD_UNITS

						worldStart = start.xyz;
						worldEnd = end.xyz;

					#else

						vUv = uv;

					#endif

					// special case for perspective projection, and segments that terminate either in, or behind, the camera plane
					// clearly the gpu firmware has a way of addressing this issue when projecting into ndc space
					// but we need to perform ndc-space calculations in the shader, so we must address this issue directly
					// perhaps there is a more elegant solution -- WestLangley

					bool perspective = ( projectionMatrix[ 2 ][ 3 ] == - 1.0 ); // 4th entry in the 3rd column

					if ( perspective ) {

						if ( start.z < 0.0 && end.z >= 0.0 ) {

							trimSegment( start, end );

						} else if ( end.z < 0.0 && start.z >= 0.0 ) {

							trimSegment( end, start );

						}

					}

					// clip space
					vec4 clipStart = projectionMatrix * start;
					vec4 clipEnd = projectionMatrix * end;

					// ndc space
					vec3 ndcStart = clipStart.xyz / clipStart.w;
					vec3 ndcEnd = clipEnd.xyz / clipEnd.w;

					// direction
					vec2 dir = ndcEnd.xy - ndcStart.xy;

					// account for clip-space aspect ratio
					dir.x *= aspect;
					dir = normalize( dir );

					#ifdef WORLD_UNITS

						// get the offset direction as perpendicular to the view vector
						vec3 worldDir = normalize( end.xyz - start.xyz );
						vec3 offset;
						if ( position.y < 0.5 ) {

							offset = normalize( cross( start.xyz, worldDir ) );

						} else {

							offset = normalize( cross( end.xyz, worldDir ) );

						}

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						float forwardOffset = dot( worldDir, vec3( 0.0, 0.0, 1.0 ) );

						// don't extend the line if we're rendering dashes because we
						// won't be rendering the endcaps
						#ifndef USE_DASH

							// extend the line bounds to encompass  endcaps
							start.xyz += - worldDir * linewidth * 0.5;
							end.xyz += worldDir * linewidth * 0.5;

							// shift the position of the quad so it hugs the forward edge of the line
							offset.xy -= dir * forwardOffset;
							offset.z += 0.5;

						#endif

						// endcaps
						if ( position.y > 1.0 || position.y < 0.0 ) {

							offset.xy += dir * 2.0 * forwardOffset;

						}

						// adjust for linewidth
						offset *= linewidth * 0.5;

						// set the world position
						worldPos = ( position.y < 0.5 ) ? start : end;
						worldPos.xyz += offset;

						// project the worldpos
						vec4 clip = projectionMatrix * worldPos;

						// shift the depth of the projected points so the line
						// segments overlap neatly
						vec3 clipPose = ( position.y < 0.5 ) ? ndcStart : ndcEnd;
						clip.z = clipPose.z * clip.w;

					#else

						vec2 offset = vec2( dir.y, - dir.x );
						// undo aspect ratio adjustment
						dir.x /= aspect;
						offset.x /= aspect;

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						// endcaps
						if ( position.y < 0.0 ) {

							offset += - dir;

						} else if ( position.y > 1.0 ) {

							offset += dir;

						}

						// adjust for linewidth
						offset *= linewidth;

						// adjust for clip-space to screen-space conversion // maybe resolution should be based on viewport ...
						offset /= resolution.y;

						// select end
						vec4 clip = ( position.y < 0.5 ) ? clipStart : clipEnd;

						// back to clip space
						offset *= clip.w;

						clip.xy += offset;

					#endif

					gl_Position = clip;

					vec4 mvPosition = ( position.y < 0.5 ) ? start : end; // this is an approximation

					#include <logdepthbuf_vertex>
					#include <clipping_planes_vertex>
					#include <fog_vertex>

				}
			`,fragmentShader:`
				uniform vec3 diffuse;
				uniform float opacity;
				uniform float linewidth;

				#ifdef USE_DASH

					uniform float dashOffset;
					uniform float dashSize;
					uniform float gapSize;

				#endif

				varying float vLineDistance;

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#include <common>
				#include <fog_pars_fragment>
				#include <logdepthbuf_pars_fragment>
				#include <clipping_planes_pars_fragment>

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
					#else
						varying vec3 vLineColor;
					#endif
				#endif

				vec2 closestLineToLine(vec3 p1, vec3 p2, vec3 p3, vec3 p4) {

					float mua;
					float mub;

					vec3 p13 = p1 - p3;
					vec3 p43 = p4 - p3;

					vec3 p21 = p2 - p1;

					float d1343 = dot( p13, p43 );
					float d4321 = dot( p43, p21 );
					float d1321 = dot( p13, p21 );
					float d4343 = dot( p43, p43 );
					float d2121 = dot( p21, p21 );

					float denom = d2121 * d4343 - d4321 * d4321;

					float numer = d1343 * d4321 - d1321 * d4343;

					mua = numer / denom;
					mua = clamp( mua, 0.0, 1.0 );
					mub = ( d1343 + d4321 * ( mua ) ) / d4343;
					mub = clamp( mub, 0.0, 1.0 );

					return vec2( mua, mub );

				}

				void main() {

					#include <clipping_planes_fragment>

					#ifdef USE_DASH

						if ( vUv.y < - 1.0 || vUv.y > 1.0 ) discard; // discard endcaps

						if ( mod( vLineDistance + dashOffset, dashSize + gapSize ) > dashSize ) discard; // todo - FIX

					#endif

					float alpha = opacity;

					#ifdef WORLD_UNITS

						// Find the closest points on the view ray and the line segment
						vec3 rayEnd = normalize( worldPos.xyz ) * 1e5;
						vec3 lineDir = worldEnd - worldStart;
						vec2 params = closestLineToLine( worldStart, worldEnd, vec3( 0.0, 0.0, 0.0 ), rayEnd );

						vec3 p1 = worldStart + lineDir * params.x;
						vec3 p2 = rayEnd * params.y;
						vec3 delta = p1 - p2;
						float len = length( delta );
						float norm = len / linewidth;

						#ifndef USE_DASH

							#ifdef USE_ALPHA_TO_COVERAGE

								float dnorm = fwidth( norm );
								alpha = 1.0 - smoothstep( 0.5 - dnorm, 0.5 + dnorm, norm );

							#else

								if ( norm > 0.5 ) {

									discard;

								}

							#endif

						#endif

					#else

						#ifdef USE_ALPHA_TO_COVERAGE

							// artifacts appear on some hardware if a derivative is taken within a conditional
							float a = vUv.x;
							float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
							float len2 = a * a + b * b;
							float dlen = fwidth( len2 );

							if ( abs( vUv.y ) > 1.0 ) {

								alpha = 1.0 - smoothstep( 1.0 - dlen, 1.0 + dlen, len2 );

							}

						#else

							if ( abs( vUv.y ) > 1.0 ) {

								float a = vUv.x;
								float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
								float len2 = a * a + b * b;

								if ( len2 > 1.0 ) discard;

							}

						#endif

					#endif

					vec4 diffuseColor = vec4( diffuse, alpha );
					#ifdef USE_COLOR
						#ifdef USE_LINE_COLOR_ALPHA
							diffuseColor *= vLineColor;
						#else
							diffuseColor.rgb *= vLineColor;
						#endif
					#endif

					#include <logdepthbuf_fragment>

					gl_FragColor = diffuseColor;

					#include <tonemapping_fragment>
					#include <${o.r>=154?"colorspace_fragment":"encodings_fragment"}>
					#include <fog_fragment>
					#include <premultiplied_alpha_fragment>

				}
			`,clipping:!0}),this.isLineMaterial=!0,this.onBeforeCompile=function(){this.transparent?this.defines.USE_LINE_COLOR_ALPHA="1":delete this.defines.USE_LINE_COLOR_ALPHA},Object.defineProperties(this,{color:{enumerable:!0,get:function(){return this.uniforms.diffuse.value},set:function(e){this.uniforms.diffuse.value=e}},worldUnits:{enumerable:!0,get:function(){return"WORLD_UNITS"in this.defines},set:function(e){!0===e?this.defines.WORLD_UNITS="":delete this.defines.WORLD_UNITS}},linewidth:{enumerable:!0,get:function(){return this.uniforms.linewidth.value},set:function(e){this.uniforms.linewidth.value=e}},dashed:{enumerable:!0,get:function(){return"USE_DASH"in this.defines},set(e){!!e!="USE_DASH"in this.defines&&(this.needsUpdate=!0),!0===e?this.defines.USE_DASH="":delete this.defines.USE_DASH}},dashScale:{enumerable:!0,get:function(){return this.uniforms.dashScale.value},set:function(e){this.uniforms.dashScale.value=e}},dashSize:{enumerable:!0,get:function(){return this.uniforms.dashSize.value},set:function(e){this.uniforms.dashSize.value=e}},dashOffset:{enumerable:!0,get:function(){return this.uniforms.dashOffset.value},set:function(e){this.uniforms.dashOffset.value=e}},gapSize:{enumerable:!0,get:function(){return this.uniforms.gapSize.value},set:function(e){this.uniforms.gapSize.value=e}},opacity:{enumerable:!0,get:function(){return this.uniforms.opacity.value},set:function(e){this.uniforms.opacity.value=e}},resolution:{enumerable:!0,get:function(){return this.uniforms.resolution.value},set:function(e){this.uniforms.resolution.value.copy(e)}},alphaToCoverage:{enumerable:!0,get:function(){return"USE_ALPHA_TO_COVERAGE"in this.defines},set:function(e){!!e!="USE_ALPHA_TO_COVERAGE"in this.defines&&(this.needsUpdate=!0),!0===e?(this.defines.USE_ALPHA_TO_COVERAGE="",this.extensions.derivatives=!0):(delete this.defines.USE_ALPHA_TO_COVERAGE,this.extensions.derivatives=!1)}}}),this.setValues(e)}}},49736:(e,t,n)=>{n.d(t,{v:()=>r});var i=n(94854);class r extends i.n{constructor(){super(),this.isLineGeometry=!0,this.type="LineGeometry"}setPositions(e){let t=e.length-3,n=new Float32Array(2*t);for(let i=0;i<t;i+=3)n[2*i]=e[i],n[2*i+1]=e[i+1],n[2*i+2]=e[i+2],n[2*i+3]=e[i+3],n[2*i+4]=e[i+4],n[2*i+5]=e[i+5];return super.setPositions(n),this}setColors(e,t=3){let n=e.length-t,i=new Float32Array(2*n);if(3===t)for(let r=0;r<n;r+=t)i[2*r]=e[r],i[2*r+1]=e[r+1],i[2*r+2]=e[r+2],i[2*r+3]=e[r+3],i[2*r+4]=e[r+4],i[2*r+5]=e[r+5];else for(let r=0;r<n;r+=t)i[2*r]=e[r],i[2*r+1]=e[r+1],i[2*r+2]=e[r+2],i[2*r+3]=e[r+3],i[2*r+4]=e[r+4],i[2*r+5]=e[r+5],i[2*r+6]=e[r+6],i[2*r+7]=e[r+7];return super.setColors(i,t),this}fromLine(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}}},57254:(e,t,n)=>{n.d(t,{X:()=>a});var i=n(63592),r=n(49736),o=n(44733);class a extends i.b{constructor(e=new r.v,t=new o.G({color:0xffffff*Math.random()})){super(e,t),this.isLine2=!0,this.type="Line2"}}},63592:(e,t,n)=>{let i,r;n.d(t,{b:()=>E});var o=n(85339),a=n(94854),s=n(44733),l=n(15353);let c=new o.IUQ,d=new o.Pq0,f=new o.Pq0,u=new o.IUQ,p=new o.IUQ,h=new o.IUQ,m=new o.Pq0,v=new o.kn4,y=new o.cZY,g=new o.Pq0,x=new o.NRn,w=new o.iyt,S=new o.IUQ;function b(e,t,n){return S.set(0,0,-t,1).applyMatrix4(e.projectionMatrix),S.multiplyScalar(1/S.w),S.x=r/n.width,S.y=r/n.height,S.applyMatrix4(e.projectionMatrixInverse),S.multiplyScalar(1/S.w),Math.abs(Math.max(S.x,S.y))}class E extends o.eaF{constructor(e=new a.n,t=new s.G({color:0xffffff*Math.random()})){super(e,t),this.isLineSegments2=!0,this.type="LineSegments2"}computeLineDistances(){let e=this.geometry,t=e.attributes.instanceStart,n=e.attributes.instanceEnd,i=new Float32Array(2*t.count);for(let e=0,r=0,o=t.count;e<o;e++,r+=2)d.fromBufferAttribute(t,e),f.fromBufferAttribute(n,e),i[r]=0===r?0:i[r-1],i[r+1]=i[r]+d.distanceTo(f);let r=new o.LuO(i,2,1);return e.setAttribute("instanceDistanceStart",new o.eHs(r,1,0)),e.setAttribute("instanceDistanceEnd",new o.eHs(r,1,1)),this}raycast(e,t){let n,a,s=this.material.worldUnits,c=e.camera;null!==c||s||console.error('LineSegments2: "Raycaster.camera" needs to be set in order to raycast against LineSegments2 while worldUnits is set to false.');let d=void 0!==e.params.Line2&&e.params.Line2.threshold||0;i=e.ray;let f=this.matrixWorld,S=this.geometry,E=this.material;if(r=E.linewidth+d,null===S.boundingSphere&&S.computeBoundingSphere(),w.copy(S.boundingSphere).applyMatrix4(f),s)n=.5*r;else{let e=Math.max(c.near,w.distanceToPoint(i.origin));n=b(c,e,E.resolution)}if(w.radius+=n,!1!==i.intersectsSphere(w)){if(null===S.boundingBox&&S.computeBoundingBox(),x.copy(S.boundingBox).applyMatrix4(f),s)a=.5*r;else{let e=Math.max(c.near,x.distanceToPoint(i.origin));a=b(c,e,E.resolution)}x.expandByScalar(a),!1!==i.intersectsBox(x)&&(s?function(e,t){let n=e.matrixWorld,a=e.geometry,s=a.attributes.instanceStart,c=a.attributes.instanceEnd,d=Math.min(a.instanceCount,s.count);for(let a=0;a<d;a++){y.start.fromBufferAttribute(s,a),y.end.fromBufferAttribute(c,a),y.applyMatrix4(n);let d=new o.Pq0,f=new o.Pq0;i.distanceSqToSegment(y.start,y.end,f,d),f.distanceTo(d)<.5*r&&t.push({point:f,pointOnLine:d,distance:i.origin.distanceTo(f),object:e,face:null,faceIndex:a,uv:null,[l.D]:null})}}(this,t):function(e,t,n){let a=t.projectionMatrix,s=e.material.resolution,c=e.matrixWorld,d=e.geometry,f=d.attributes.instanceStart,x=d.attributes.instanceEnd,w=Math.min(d.instanceCount,f.count),S=-t.near;i.at(1,h),h.w=1,h.applyMatrix4(t.matrixWorldInverse),h.applyMatrix4(a),h.multiplyScalar(1/h.w),h.x*=s.x/2,h.y*=s.y/2,h.z=0,m.copy(h),v.multiplyMatrices(t.matrixWorldInverse,c);for(let t=0;t<w;t++){if(u.fromBufferAttribute(f,t),p.fromBufferAttribute(x,t),u.w=1,p.w=1,u.applyMatrix4(v),p.applyMatrix4(v),u.z>S&&p.z>S)continue;if(u.z>S){let e=u.z-p.z,t=(u.z-S)/e;u.lerp(p,t)}else if(p.z>S){let e=p.z-u.z,t=(p.z-S)/e;p.lerp(u,t)}u.applyMatrix4(a),p.applyMatrix4(a),u.multiplyScalar(1/u.w),p.multiplyScalar(1/p.w),u.x*=s.x/2,u.y*=s.y/2,p.x*=s.x/2,p.y*=s.y/2,y.start.copy(u),y.start.z=0,y.end.copy(p),y.end.z=0;let d=y.closestPointToPointParameter(m,!0);y.at(d,g);let h=o.cj9.lerp(u.z,p.z,d),w=h>=-1&&h<=1,b=m.distanceTo(g)<.5*r;if(w&&b){y.start.fromBufferAttribute(f,t),y.end.fromBufferAttribute(x,t),y.start.applyMatrix4(c),y.end.applyMatrix4(c);let r=new o.Pq0,a=new o.Pq0;i.distanceSqToSegment(y.start,y.end,a,r),n.push({point:a,pointOnLine:r,distance:i.origin.distanceTo(a),object:e,face:null,faceIndex:t,uv:null,[l.D]:null})}}}(this,c,t))}}onBeforeRender(e){let t=this.material.uniforms;t&&t.resolution&&(e.getViewport(c),this.material.uniforms.resolution.value.set(c.z,c.w))}}},88945:(e,t,n)=>{n.d(t,{A:()=>i});function i(){return(i=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var i in n)({}).hasOwnProperty.call(n,i)&&(e[i]=n[i])}return e}).apply(null,arguments)}},94854:(e,t,n)=>{n.d(t,{n:()=>a});var i=n(85339);let r=new i.NRn,o=new i.Pq0;class a extends i.CmU{constructor(){super(),this.isLineSegmentsGeometry=!0,this.type="LineSegmentsGeometry",this.setIndex([0,2,1,2,3,1,2,4,3,4,5,3,4,6,5,6,7,5]),this.setAttribute("position",new i.qtW([-1,2,0,1,2,0,-1,1,0,1,1,0,-1,0,0,1,0,0,-1,-1,0,1,-1,0],3)),this.setAttribute("uv",new i.qtW([-1,2,1,2,-1,1,1,1,-1,-1,1,-1,-1,-2,1,-2],2))}applyMatrix4(e){let t=this.attributes.instanceStart,n=this.attributes.instanceEnd;return void 0!==t&&(t.applyMatrix4(e),n.applyMatrix4(e),t.needsUpdate=!0),null!==this.boundingBox&&this.computeBoundingBox(),null!==this.boundingSphere&&this.computeBoundingSphere(),this}setPositions(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));let n=new i.LuO(t,6,1);return this.setAttribute("instanceStart",new i.eHs(n,3,0)),this.setAttribute("instanceEnd",new i.eHs(n,3,3)),this.computeBoundingBox(),this.computeBoundingSphere(),this}setColors(e,t=3){let n;e instanceof Float32Array?n=e:Array.isArray(e)&&(n=new Float32Array(e));let r=new i.LuO(n,2*t,1);return this.setAttribute("instanceColorStart",new i.eHs(r,t,0)),this.setAttribute("instanceColorEnd",new i.eHs(r,t,t)),this}fromWireframeGeometry(e){return this.setPositions(e.attributes.position.array),this}fromEdgesGeometry(e){return this.setPositions(e.attributes.position.array),this}fromMesh(e){return this.fromWireframeGeometry(new i.XJ7(e.geometry)),this}fromLineSegments(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}computeBoundingBox(){null===this.boundingBox&&(this.boundingBox=new i.NRn);let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;void 0!==e&&void 0!==t&&(this.boundingBox.setFromBufferAttribute(e),r.setFromBufferAttribute(t),this.boundingBox.union(r))}computeBoundingSphere(){null===this.boundingSphere&&(this.boundingSphere=new i.iyt),null===this.boundingBox&&this.computeBoundingBox();let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;if(void 0!==e&&void 0!==t){let n=this.boundingSphere.center;this.boundingBox.getCenter(n);let i=0;for(let r=0,a=e.count;r<a;r++)o.fromBufferAttribute(e,r),i=Math.max(i,n.distanceToSquared(o)),o.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(o));this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error("THREE.LineSegmentsGeometry.computeBoundingSphere(): Computed radius is NaN. The instanced position data is likely to have NaN values.",this)}}toJSON(){}applyMatrix(e){return console.warn("THREE.LineSegmentsGeometry: applyMatrix() has been renamed to applyMatrix4()."),this.applyMatrix4(e)}}}}]);